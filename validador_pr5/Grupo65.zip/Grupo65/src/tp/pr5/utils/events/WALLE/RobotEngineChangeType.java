/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tp.pr5.utils.events.WALLE;

/**
 *
 * @author
 * Manu343726
 */
public enum RobotEngineChangeType {
    MATERIAL_CHANGE , FUEL_CHANGE , QUIT_REQUESTED
}
