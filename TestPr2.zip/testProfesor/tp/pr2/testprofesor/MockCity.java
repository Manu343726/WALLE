package tp.pr2.testprofesor;

import tp.pr2.City;
import tp.pr2.Street;

public class MockCity extends City {

	public MockCity(Street[] cityMap) {
		super(cityMap);
	}

	public MockCity() {
		// TODO Auto-generated constructor stub
	}

}
