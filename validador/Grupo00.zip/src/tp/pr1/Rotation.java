package tp.pr1;

/***
 * Represents a robot rotation
 */
public enum Rotation {
	
	LEFT, RIGHT, UNKNOWN;
	
}
