package tp.pr3.testprofesor;

import tp.pr3.City;
import tp.pr3.Street;

public class MockCity extends City {

	public MockCity(Street[] cityMap) {
		super(cityMap);
	}

	public MockCity() {
		// TODO Auto-generated constructor stub
	}

}
