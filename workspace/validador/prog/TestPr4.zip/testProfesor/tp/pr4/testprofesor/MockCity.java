package tp.pr4.testprofesor;

import tp.pr4.City;
import tp.pr4.Street;

public class MockCity extends City {

	public MockCity(Street[] cityMap) {
		super(cityMap);
	}

	public MockCity() {
		// TODO Auto-generated constructor stub
	}

}
