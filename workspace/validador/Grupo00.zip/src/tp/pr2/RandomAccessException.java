package tp.pr2;

public class RandomAccessException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public RandomAccessException(){}
	public RandomAccessException(String what){super(what);}
}
