package tp.pr2;

public enum GenericContainerMemoryState {
	OK,
	NEEDSEXPAND,
	NEEDSCONTRACT
}
