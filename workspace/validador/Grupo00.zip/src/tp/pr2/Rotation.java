//OK//

package tp.pr2;


/***
 * Represents a robot rotation
 */
public enum Rotation {
	LEFT, RIGHT, UNKNOWN;	
}
