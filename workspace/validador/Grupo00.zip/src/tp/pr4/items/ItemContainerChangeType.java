/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tp.pr4.items;

/**
 * Represents the set of changes that can occurs in a item container
 * @author
 * Laura María de Castro Saturio , Manuel Sánchez Pérez
 */
public enum ItemContainerChangeType {
    ITEM_ADDED,
    ITEM_DELETED
}
