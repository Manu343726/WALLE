package tp.pr3;

public enum GenericContainerMemoryState {
	OK,
	NEEDSEXPAND,
	NEEDSCONTRACT
}
