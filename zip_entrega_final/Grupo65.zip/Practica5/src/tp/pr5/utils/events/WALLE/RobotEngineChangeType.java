/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tp.pr5.utils.events.WALLE;

/**
 * Set of robot engine events types.
 * @author
 * Manuel Sánchez Pérez
 */
public enum RobotEngineChangeType {
    MATERIAL_CHANGE , FUEL_CHANGE , QUIT_REQUESTED , MESSAGE_POSTED
}
