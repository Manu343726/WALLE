WALL-E  - Tecnología de la Programación, prácticas de la asignatura
===================================================================

Autores:
--------

Manuel Sánchez Pérez

Organización del repositorio:
-----------------------------

El repositorio incluye un proyecto de netbeans (Compatible con Netbeans 7.2) ya configurado, en la subcarpeta WALLE/. Dentro de ésta se encuentra el código fuente (Directorio WALLE/src/) y la documentación de la práctica (Directorio WALLE/dist/javadoc).

Validador
----------

El repositorio incluye un archivo zip (Grupo65.zip) en su directorio raiz, totalmente listo para ser validado.
Además se incluye una serie de anotaciones sobre los resultados de los tests (Archivo "NOTA_SOBRE_VALIDADOR_LEEME_ALBERTO.txt"). 

Backup de las prácticas:
------------------------

Además del repositorio, las prácticas están sincronizadas en mi cuenta de dropbox: 
https://www.dropbox.com/sh/tvfh9u69wl6de0d/Qb92cplzhy

He marcado el repositorio como público para que puedas acceder en el caso de que hubiera algún problema con el zip de la entrega (No debería). Así puedes acceder a la lista de versiones de la práctica (Rama master).
https://github.com/Manu343726/WALLE

**Nota: He eliminado los metadatos del repositorio (.git) para que el repo cupiera en el zip (Los metadatos ocupaban cerca de 9MB)**